
#define HOST_TYPE "i686-pc-linux-gnu"
