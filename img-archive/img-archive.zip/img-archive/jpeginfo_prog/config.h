/* config.h.  Generated automatically by configure.  */
/* config.h.in. 
 * $Id$
 *
 */


/* Define if you have the ANSI C header files.  */
/* #undef STDC_HEADERS */

/* The number of bytes in a int.  */
#define SIZEOF_INT 0

/* The number of bytes in a long.  */
#define SIZEOF_LONG 0

/* Define if you have the getopt_long function.  */
/* #undef HAVE_GETOPT_LONG */

/* Define if you have the <getopt.h> header file.  */
#define HAVE_GETOPT_H 1

/* Define if you have the <string.h> header file.  */
#define HAVE_STRING_H 1

/* Define if you have the <unistd.h> header file.  */
#define HAVE_UNISTD_H 1

/* Define if you have the jpeg library (-ljpeg).  */
#define HAVE_LIBJPEG 1



/* Define if you have broken jmorecfg.h (SGI's usually have this problem) */
#define BROKEN_METHODDEF 1

#define HOST_TYPE "i686-pc-linux-gnu"


/* eof :-) */
